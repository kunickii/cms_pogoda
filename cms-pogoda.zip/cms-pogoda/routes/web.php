<?php

use App\Http\Controllers\ClientController;
use App\Http\Controllers\WeatherMessageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Admin\ForecastController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Tutaj definiujemy wszystkie trasy dostępne w przeglądarce.
|
*/

// Strona główna dla klienta (widok publiczny)
Route::get('/', [ClientController::class, 'index']);

// Panel admina – CRUD dla komunikatów pogodowych (wymaga logowania)
Route::middleware(['auth'])->group(function () {
    Route::resource('weather', WeatherMessageController::class);

    // Profile użytkownika
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Dashboard (po zalogowaniu)
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');


// ------------------------------------------
// PANEL ADMINA – FORECASTS (prognozy pogody)
// ------------------------------------------
Route::middleware(['auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::resource('forecasts', ForecastController::class);
    });

require __DIR__.'/auth.php';
