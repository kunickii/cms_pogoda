

<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Prognozy pogody</h1>

    <a href="<?php echo e(route('admin.forecasts.create')); ?>" class="btn btn-primary mb-3">
        Dodaj nową prognozę
    </a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Miasto</th>
                <th>Data</th>
                <th>Temperatura</th>
                <th>Warunki</th>
                <th>Opublikowana?</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $forecasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forecast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($forecast->city); ?></td>
                <td><?php echo e($forecast->date); ?></td>
                <td><?php echo e($forecast->temperature); ?>°C</td>
                <td><?php echo e($forecast->conditions); ?></td>
                <td><?php echo e($forecast->published ? 'Tak' : 'Nie'); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.forecasts.edit', $forecast)); ?>" class="btn btn-sm btn-warning">Edytuj</a>

                    <form action="<?php echo e(route('admin.forecasts.destroy', $forecast)); ?>"
                          method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger"
                                onclick="return confirm('Na pewno usunąć?');">
                            Usuń
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo e($forecasts->links()); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-pogoda\resources\views/admin/forecasts/index.blade.php ENDPATH**/ ?>