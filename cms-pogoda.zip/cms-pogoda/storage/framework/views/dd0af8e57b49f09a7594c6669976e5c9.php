

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dodaj prognozę</h1>

    <?php echo $__env->make('admin.forecasts.form', [
        'action' => route('admin.forecasts.store'),
        'method' => 'POST',
        'forecast' => null
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-pogoda\resources\views/admin/forecasts/create.blade.php ENDPATH**/ ?>