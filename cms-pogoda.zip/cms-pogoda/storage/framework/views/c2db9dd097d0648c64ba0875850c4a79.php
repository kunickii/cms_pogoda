<h1>Aktualne komunikaty pogodowe</h1>


<?php if($weatherData): ?>
    <h2>Pogoda w Warszawie</h2>
    <p>Temperatura: <?php echo e($weatherData['temperature']); ?>°C</p>
    <p>Wiatr: <?php echo e($weatherData['windspeed']); ?> km/h</p>
<?php endif; ?>

<hr>


<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h2><?php echo e($msg->title); ?> (<?php echo e($msg->city); ?>)</h2>
    <p><?php echo e($msg->content); ?></p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<h2>Prognozy pogodowe</h2>

<?php if($forecasts->isEmpty()): ?>
    <p>Brak prognoz do wyświetlenia.</p>
<?php else: ?>
    <?php $__currentLoopData = $forecasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $forecast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($forecast->city); ?> — <?php echo e($forecast->date); ?></h3>
        <p>Temperatura: <?php echo e($forecast->temperature); ?>°C</p>
        <p>Warunki: <?php echo e($forecast->conditions); ?></p>
        <p>Status: <?php echo e($forecast->published ? 'Opublikowana' : 'Ukryta'); ?></p>
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\cms-pogoda\resources\views/client/index.blade.php ENDPATH**/ ?>