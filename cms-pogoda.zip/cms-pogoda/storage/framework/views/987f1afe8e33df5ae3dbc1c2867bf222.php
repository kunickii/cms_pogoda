

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edytuj prognozę</h1>

    <?php echo $__env->make('admin.forecasts.form', [
        'action' => route('admin.forecasts.update', $forecast),
        'method' => 'PUT',
        'forecast' => $forecast
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\cms-pogoda\resources\views/admin/forecasts/edit.blade.php ENDPATH**/ ?>