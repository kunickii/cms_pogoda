<h1>Aktualne komunikaty pogodowe</h1>

{{-- Pogoda z API --}}
@if($weatherData)
    <h2>Pogoda w Warszawie</h2>
    <p>Temperatura: {{ $weatherData['temperature'] }}°C</p>
    <p>Wiatr: {{ $weatherData['windspeed'] }} km/h</p>
@endif

<hr>

{{-- Komunikaty pogodowe z bazy --}}
@foreach($messages as $msg)
    <h2>{{ $msg->title }} ({{ $msg->city }})</h2>
    <p>{{ $msg->content }}</p>
    <hr>
@endforeach

{{-- PROGNOZY Z BAZY --}}
<h2>Prognozy pogodowe</h2>

@if($forecasts->isEmpty())
    <p>Brak prognoz do wyświetlenia.</p>
@else
    @foreach($forecasts as $forecast)
        <h3>{{ $forecast->city }} — {{ $forecast->date }}</h3>
        <p>Temperatura: {{ $forecast->temperature }}°C</p>
        <p>Warunki: {{ $forecast->conditions }}</p>
        <p>Status: {{ $forecast->published ? 'Opublikowana' : 'Ukryta' }}</p>
        <hr>
    @endforeach
@endif
