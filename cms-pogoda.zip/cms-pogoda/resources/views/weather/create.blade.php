@extends('layouts.app')

@section('content')
<h1>Dodaj nowy komunikat pogodowy</h1>

<form action="{{ route('weather.store') }}" method="POST">
    @csrf
    <div>
        <label>Tytuł:</label>
        <input type="text" name="title">
    </div>
    <div>
        <label>Miasto:</label>
        <input type="text" name="city">
    </div>
    <div>
        <label>Treść:</label>
        <textarea name="content"></textarea>
    </div>
    <button type="submit">Zapisz</button>
</form>
@endsection
