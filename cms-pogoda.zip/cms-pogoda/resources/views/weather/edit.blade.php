@extends('layouts.app')

@section('content')
<h1>Edytuj komunikat pogodowy</h1>

<form action="{{ route('weather.update', $weatherMessage->id) }}" method="POST">
    @csrf
    @method('PUT')
    <div>
        <label>Tytuł:</label>
        <input type="text" name="title" value="{{ $weatherMessage->title }}">
    </div>
    <div>
        <label>Miasto:</label>
        <input type="text" name="city" value="{{ $weatherMessage->city }}">
    </div>
    <div>
        <label>Treść:</label>
        <textarea name="content">{{ $weatherMessage->content }}</textarea>
    </div>
    <button type="submit">Zapisz</button>
</form>
@endsection
