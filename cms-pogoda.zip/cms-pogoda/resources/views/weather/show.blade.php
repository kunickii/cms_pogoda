@extends('layouts.app')

@section('content')
<h1>{{ $weatherMessage->title }} ({{ $weatherMessage->city }})</h1>

<p>{{ $weatherMessage->content }}</p>

<a href="{{ route('weather.index') }}">Powrót do listy</a>
<a href="{{ route('weather.edit', $weatherMessage->id) }}">Edytuj</a>

<form action="{{ route('weather.destroy', $weatherMessage->id) }}" method="POST" style="display:inline;">
    @csrf
    @method
