@extends('layouts.app') <!-- używa layoutu Breeze -->

@section('content')
<h1>Panel admina – komunikaty pogodowe</h1>

<a href="{{ route('weather.create') }}">Dodaj nowy komunikat</a>

<table border="1" cellpadding="5" cellspacing="0">
    <tr>
        <th>Tytuł</th>
        <th>Miasto</th>
        <th>Akcje</th>
    </tr>
    @foreach($weatherMessages as $msg)
    <tr>
        <td>{{ $msg->title }}</td>
        <td>{{ $msg->city }}</td>
        <td>
            <a href="{{ route('weather.edit', $msg->id) }}">Edytuj</a> |
            <form action="{{ route('weather.destroy', $msg->id) }}" method="POST" style="display:inline;">
                @csrf
                @method('DELETE')
                <button type="submit">Usuń</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>
@endsection
