@extends('layouts.app')

@section('content')
<div class="container">

    <h1>Prognozy pogody</h1>

    <a href="{{ route('admin.forecasts.create') }}" class="btn btn-primary mb-3">
        Dodaj nową prognozę
    </a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Miasto</th>
                <th>Data</th>
                <th>Temperatura</th>
                <th>Warunki</th>
                <th>Opublikowana?</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            @foreach($forecasts as $forecast)
            <tr>
                <td>{{ $forecast->city }}</td>
                <td>{{ $forecast->date }}</td>
                <td>{{ $forecast->temperature }}°C</td>
                <td>{{ $forecast->conditions }}</td>
                <td>{{ $forecast->published ? 'Tak' : 'Nie' }}</td>
                <td>
                    <a href="{{ route('admin.forecasts.edit', $forecast) }}" class="btn btn-sm btn-warning">Edytuj</a>

                    <form action="{{ route('admin.forecasts.destroy', $forecast) }}"
                          method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button class="btn btn-sm btn-danger"
                                onclick="return confirm('Na pewno usunąć?');">
                            Usuń
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    {{ $forecasts->links() }}

</div>
@endsection
