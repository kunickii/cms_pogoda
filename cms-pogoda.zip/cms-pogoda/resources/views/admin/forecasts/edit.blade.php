@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edytuj prognozę</h1>

    @include('admin.forecasts.form', [
        'action' => route('admin.forecasts.update', $forecast),
        'method' => 'PUT',
        'forecast' => $forecast
    ])
</div>
@endsection
