@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Dodaj prognozę</h1>

    @include('admin.forecasts.form', [
        'action' => route('admin.forecasts.store'),
        'method' => 'POST',
        'forecast' => null
    ])
</div>
@endsection
