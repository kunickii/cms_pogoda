<form action="{{ $action }}" method="post">
    @csrf
    @if($method !== 'POST')
    @method(strtoupper($method))
@endif


    <div class="mb-3">
        <label class="form-label">Miasto</label>
        <input type="text" name="city" class="form-control"
               value="{{ old('city', $forecast->city ?? '') }}" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Data</label>
        <input type="date" name="date" class="form-control"
               value="{{ old('date', $forecast->date ?? '') }}" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Temperatura (°C)</label>
        <input type="number" step="0.1" name="temperature" class="form-control"
               value="{{ old('temperature', $forecast->temperature ?? '') }}" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Warunki</label>
        <input type="text" name="conditions" class="form-control"
               value="{{ old('conditions', $forecast->conditions ?? '') }}">
    </div>

    <div class="form-check mb-3">
        <input type="checkbox" name="published" class="form-check-input"
               {{ old('published', $forecast->published ?? true) ? 'checked' : '' }}>
        <label class="form-check-label">Opublikowana</label>
    </div>

    <button type="submit" class="btn btn-success">Zapisz</button>

</form>
