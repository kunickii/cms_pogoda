<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WeatherMessage extends Model
{
    use HasFactory;

    // Dopuszczamy masowe przypisywanie tych pól
    protected $fillable = [
        'title',
        'content',
        'city',
    ];
}
