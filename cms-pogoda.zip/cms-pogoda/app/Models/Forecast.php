<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Forecast extends Model
{
    // WYMUSZAMY użytą tabelę — to rozwiązuje problem z brakiem ID
    protected $table = 'forecasts';

    // Pola do zapisu
    protected $fillable = [
        'city',
        'date',
        'temperature',
        'conditions',
        'published',
    ];
}
