<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Forecast;
use Illuminate\Http\Request;

class ForecastController extends Controller
{
    public function index()
    {
        $forecasts = Forecast::orderBy('id', 'desc')->paginate(10);

        return view('admin.forecasts.index', [
            'forecasts' => $forecasts
        ]);
    }

    public function create()
    {
        return view('admin.forecasts.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'city' => 'required|string|max:255',
            'date' => 'required|date',
            'temperature' => 'required|numeric',
            'conditions' => 'nullable|string',
            'published' => 'boolean',
        ]);

        $data['published'] = $request->has('published');

        Forecast::create($data);

        return redirect()->route('admin.forecasts.index')
                         ->with('success', 'Prognoza została dodana.');
    }

    public function edit(Forecast $forecast)
    {
        return view('admin.forecasts.edit', [
            'forecast' => $forecast
        ]);
    }

    public function update(Request $request, Forecast $forecast)
    {
        $data = $request->validate([
            'city' => 'required|string|max:255',
            'date' => 'required|date',
            'temperature' => 'required|numeric',
            'conditions' => 'nullable|string',
            'published' => 'boolean',
        ]);

        $data['published'] = $request->has('published');

        $forecast->update($data);

        return redirect()->route('admin.forecasts.index')
                         ->with('success', 'Prognoza została zaktualizowana.');
    }

    public function destroy(Forecast $forecast)
    {
        $forecast->delete();

        return redirect()->route('admin.forecasts.index')
                         ->with('success', 'Prognoza została usunięta.');
    }
}
