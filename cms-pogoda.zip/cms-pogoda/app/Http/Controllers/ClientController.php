<?php

namespace App\Http\Controllers;

use App\Models\WeatherMessage;
use App\Models\Forecast;          // ← dodaliśmy model Forecast
use Illuminate\Support\Facades\Http;

class ClientController extends Controller
{
    /**
     * Wyświetla stronę główną dla klienta:
     * - komunikaty pogodowe (z bazy)
     * - prognozy pogodowe (z bazy)
     * - aktualną pogodę z API
     */
    public function index()
    {
        // Pobiera komunikaty pogodowe
        $messages = WeatherMessage::latest()->get();

        // Pobiera PROGNOZY z tabeli forecasts
        $forecasts = Forecast::where('published', 1)
                            ->orderBy('date', 'asc')
                            ->get();

        // Pogoda z API (Warszawa)
        $weatherApiUrl = 'https://api.open-meteo.com/v1/forecast?latitude=52.23&longitude=21.01&current_weather=true';
        $response = Http::get($weatherApiUrl);

        $weatherData = null;
        if ($response->ok()) {
            $weatherData = $response->json()['current_weather'];
        }

        // Przekazanie WSZYSTKICH danych do widoku
        return view('client.index', compact('messages', 'forecasts', 'weatherData'));
    }
}
