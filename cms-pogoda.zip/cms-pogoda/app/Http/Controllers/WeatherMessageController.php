<?php

namespace App\Http\Controllers;

use App\Models\WeatherMessage;
use Illuminate\Http\Request;

class WeatherMessageController extends Controller
{
    /**
     * Wyświetla listę komunikatów pogodowych (panel admina).
     */
    public function index()
    {
        $weatherMessages = WeatherMessage::all(); // pobiera wszystkie rekordy
        return view('weather.index', compact('weatherMessages')); // przekazuje do widoku
    }

    /**
     * Formularz tworzenia nowego komunikatu.
     */
    public function create()
    {
        return view('weather.create');
    }

    /**
     * Zapis nowego komunikatu do bazy.
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        WeatherMessage::create($request->all());

        return redirect()->route('weather.index')->with('success', 'Komunikat dodany!');
    }

    /**
     * Wyświetla pojedynczy komunikat.
     */
    public function show(WeatherMessage $weatherMessage)
    {
        return view('weather.show', compact('weatherMessage'));
    }

    /**
     * Formularz edycji komunikatu.
     */
    public function edit(WeatherMessage $weatherMessage)
    {
        return view('weather.edit', compact('weatherMessage'));
    }

    /**
     * Zapis zmian w komunikacie.
     */
    public function update(Request $request, WeatherMessage $weatherMessage)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $weatherMessage->update($request->all());

        return redirect()->route('weather.index')->with('success', 'Komunikat zaktualizowany!');
    }

    /**
     * Usuwa komunikat z bazy.
     */
    public function destroy(WeatherMessage $weatherMessage)
    {
        $weatherMessage->delete();
        return redirect()->route('weather.index')->with('success', 'Komunikat usunięty!');
    }
}
